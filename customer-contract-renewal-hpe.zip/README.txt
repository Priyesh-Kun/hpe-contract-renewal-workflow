Customer Contract Expiry & Renewal Brief

This bundle preserves the selected native authoring revision and a scalar input
example. It contains no execution outputs, files, templates, credentials, runtime
URLs, account information, or user and organization identifiers. Source identity
and the SHA256 of the private source snapshot are recorded in workflow.json.
Source text is JSON escaped to preserve its exact punctuation.

Unzip customer-contract-renewal-hpe.zip into a fresh directory, then run:
  python3 import-workflow.py --check
The default is also an offline check. This checks reviewed payload integrity and
native authoring structure. It does not contact HPE or validate its live services.

On the HPE accessnode, port-forward the API to loopback:
  kubectl --context user1-context -n development port-forward svc/dostack-api 18080:8080
In another interactive terminal, run:
  python3 import-workflow.py --apply --endpoint http://127.0.0.1:18080
The direct API uses the root path. An optional /api suffix is supported for a
proxied endpoint. Application deployments remain managed through Argo CD.
Enter HPE admin credentials at the prompts. Credentials remain in process memory.
The importer disables proxies and redirects, verifies admin login and organization
slug dostack-hpe, creates a native draft, checks the target authoring, then saves
with target-generated IDs and verifies the saved workflow and version. It never
submits caller-controlled compiled fields or uses the legacy migration endpoint.
An application without native authoring support cannot accept this transfer.

Apply creates a new workflow on every run. It is not idempotent. A failed create
or Save can leave a draft or a saved workflow. Inspect printed target IDs and the
HPE UI before retrying. An HTTP timeout can leave an unconfirmed write. No cleanup,
deployment, execution, connection configuration, or capability provisioning occurs.

HPE needs compatible native authoring/Save support, IBSV and RADAR data/API
connections, tabular_query, standard and premium LLM routing, search for step9,
and docgen. No external file or template assets are required. The input example is
customer_st_id="REPLACE_WITH_CUSTOMER_ST_ID" and is not submitted as an execution by this importer.

Validation evidence: a read-only source-compiler check in sandbox API version
0.1.0-dev.88 compiled the exact authoring with fresh target IDs and version 1,
producing 10 tasks and zero warnings. Its revision matched the source revision:
ee3a32cbbbc708fe4df90c05c3590aee0c66d77a2e46a2cdc387e93e98f6fe0c
This is source-compiler evidence, not live HPE validation or execution evidence.

The exact HPE API image 0.1.0-dev.72 source (commit
80f0d327bafe11b6b96b6f54045eab33f0b5d9b1) also compiled this authoring offline:
10 tasks, zero warnings, and the same revision. This verifies that compiler
source, not the live HPE API, credentials, connectors, or execution. HPE must have its own IBSV
and RADAR SQL connections; their live configuration was not checked.

The HPE worker image 0.1.0-dev.62 source (commit
176312fe0dbca4dcb54b52b265a3109fa38b0f1a) validated the program, ASL, and Step
models offline. It compiled an execution plan with all 10 tasks using the scalar
example and placeholder queue names. This involved no execution or network calls.
