#!/usr/bin/env python3
"""Check this native workflow transfer, or explicitly save it through loopback HPE."""
import argparse
import getpass
import hashlib
import json
from pathlib import Path
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
from uuid import UUID

NATIVE = "dostack.native-authoring.v1"
PAYLOAD_SHA256 = "5618866295d4e1336d234d6c0faa9e8fd83ad6cef465a1ec73f9ac77289931e8"
FILES = {"workflow.json", "manifest.json", "README.txt", "import-workflow.py"}
AUTHORED_FIELDS = {"authoring_format", "name", "description", "english_workflow",
                   "step_configs", "input_schema", "source_task"}


class TransferError(Exception):
    pass


def unique_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise TransferError("duplicate JSON member")
        result[key] = value
    return result


def read_json(raw):
    try:
        return json.loads(raw, object_pairs_hook=unique_pairs)
    except (ValueError, UnicodeError):
        raise TransferError("invalid transfer JSON") from None


def check_safe(value):
    if isinstance(value, dict):
        for key, child in value.items():
            normalized = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", key).lower()
            if normalized in {"password", "secret", "api_key", "access_token", "credentials",
                              "org_id", "user_id", "created_by", "account_id", "authorization"}:
                raise TransferError("identity or credential field in transfer")
            check_safe(child)
    elif isinstance(value, list):
        for child in value:
            check_safe(child)
    elif isinstance(value, str):
        if re.search(r"arn:aws:|s3://|amazonaws\.com|X-Amz-(?:Signature|Credential)|-----BEGIN .*PRIVATE KEY|\b(?:AKIA|ASIA)[A-Z0-9]{16}\b", value, re.I):
            raise TransferError("source resource or credential in transfer")
        if re.search(r"https?://(?!\.\.\.)", value):
            raise TransferError("runtime URL in transfer")


def validate_bundle(root):
    root = Path(root)
    allowed = FILES | {"customer-contract-renewal-hpe.zip", "__pycache__"}
    if root.is_symlink() or not root.is_dir() or {p.name for p in root.iterdir()} - allowed:
        raise TransferError("unexpected transfer inventory")
    for name in FILES:
        path = root / name
        if path.is_symlink() or not path.is_file() or path.stat().st_size > 2_000_000:
            raise TransferError("missing or unsafe transfer member")
    manifest = read_json((root / "manifest.json").read_bytes())
    if not isinstance(manifest, dict) or set(manifest) != {"format", "files"} or manifest["format"] != "dostack.native-transfer.v1":
        raise TransferError("invalid native transfer manifest")
    if not isinstance(manifest["files"], dict) or set(manifest["files"]) != FILES - {"manifest.json"}:
        raise TransferError("invalid transfer manifest inventory")
    for name, digest in manifest["files"].items():
        if hashlib.sha256((root / name).read_bytes()).hexdigest() != digest:
            raise TransferError("transfer checksum mismatch")
    raw = (root / "workflow.json").read_bytes()
    if hashlib.sha256(raw).hexdigest() != PAYLOAD_SHA256:
        raise TransferError("payload differs from reviewed source projection")
    data = read_json(raw)
    if not isinstance(data, dict) or set(data) != {"authoring", "inputs", "provenance"}:
        raise TransferError("invalid native transfer")
    authored = data["authoring"]
    if not isinstance(authored, dict) or set(authored) != AUTHORED_FIELDS or authored.get("authoring_format") != NATIVE:
        raise TransferError("legacy application is unsupported; native authoring is required")
    english = decode_english(authored["english_workflow"])
    if (not isinstance(english, dict) or english.get("workflow_type") != "mermaid"
            or not english.get("workflow_definition", "").lstrip().startswith("stateDiagram-v2")
            or len(authored["step_configs"]) != 10):
        raise TransferError("invalid native authoring fields")
    if data["inputs"] != {"customer_st_id": "REPLACE_WITH_CUSTOMER_ST_ID"}:
        raise TransferError("invalid scalar input example")
    check_safe(data)
    return data


def decode_english(value):
    return read_json(value) if isinstance(value, str) else value


def endpoint_url(value):
    parsed = urllib.parse.urlsplit(value)
    if (parsed.scheme != "http" or parsed.hostname not in {"127.0.0.1", "localhost", "::1"}
            or parsed.username or parsed.password or parsed.query or parsed.fragment
            or parsed.path.rstrip("/") not in {"", "/api"}):
        raise TransferError("endpoint must be a loopback HTTP URL at root or /api")
    return value.rstrip("/")


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def request(opener, method, url, body=None, token=None):
    headers = {"Accept": "application/json"}
    if token:
        headers["Authorization"] = "Bearer " + token
    raw = None
    if body is not None:
        headers["Content-Type"] = "application/json"
        raw = json.dumps(body, ensure_ascii=True, allow_nan=False).encode("ascii")
    req = urllib.request.Request(url, data=raw, headers=headers, method=method)
    try:
        with opener.open(req, timeout=30) as response:
            raw = response.read(2_000_001)
    except urllib.error.HTTPError as error:
        raise TransferError(f"HPE request failed with HTTP {error.code}") from None
    except (urllib.error.URLError, TimeoutError, OSError):
        raise TransferError("HPE request failed; read target state before retrying") from None
    if len(raw) > 2_000_000:
        raise TransferError("HPE response exceeded size limit")
    result = read_json(raw)
    if not isinstance(result, dict):
        raise TransferError("unexpected HPE response")
    return result


def target_uuid(value):
    try:
        UUID(value)
    except (ValueError, TypeError, AttributeError):
        raise TransferError("HPE did not return valid target IDs") from None
    return value


def verify_version(version, authored, wid, vid, number, saved=False):
    if (version.get("authoring_format") != NATIVE or version.get("authoring_stage") != "compiled"
            or version.get("id") != vid or version.get("workflow_id") != wid
            or version.get("version_number") != number or version.get("total_steps") != 10
            or version.get("asl_program", {}).get("workflow", {}).get("source", {}).get("source_format") != NATIVE):
        raise TransferError("target did not compile native authoring; legacy application is unsupported")
    for field in ("step_configs", "input_schema", "english_workflow"):
        expected, actual = authored[field], version.get(field)
        if field == "english_workflow":
            expected, actual = decode_english(expected), decode_english(actual)
        if actual != expected:
            raise TransferError("target authoring differs from source")
    if saved and version.get("status") != "SAVED":
        raise TransferError("target version Save was not confirmed")


def apply_bundle(root, endpoint, opener, email, password):
    data = validate_bundle(root)
    endpoint = endpoint_url(endpoint)
    login = request(opener, "POST", endpoint + "/auth/login", {"email": email, "password": password})
    user, token = login.get("user", {}), login.get("access_token")
    if (not isinstance(user, dict) or user.get("is_admin") is not True
            or not isinstance(user.get("active_org_id"), str) or not user["active_org_id"]
            or not isinstance(token, str) or not token):
        raise TransferError("login must identify an admin with an active organization")
    org = request(opener, "GET", endpoint + "/organizations/" + urllib.parse.quote(user["active_org_id"], safe=""), token=token)
    if org.get("slug") != "dostack-hpe":
        raise TransferError("active organization must be dostack-hpe")
    created = request(opener, "POST", endpoint + "/workflow", {**data["authoring"], "status": "WIP"}, token)
    created = created.get("data", {})
    wid, vid = target_uuid(created.get("id")), target_uuid(created.get("version_id"))
    number = created.get("version_number")
    if (created.get("authoring_format") != NATIVE or created.get("current_version_id") != vid
            or type(number) is not int or number < 1
            or wid == data["provenance"]["source_workflow_id"] or vid == data["provenance"]["source_version_id"]):
        raise TransferError("native creation was not confirmed; inspect target before retrying")
    print(f"Created draft workflow_id={wid} version_id={vid}; inspect these IDs if Save fails.")
    version_url = endpoint + f"/workflows/{wid}/versions/{vid}"
    verify_version(request(opener, "GET", version_url, token=token), data["authoring"], wid, vid, number)
    saved = request(opener, "PUT", endpoint + "/workflow/" + wid,
                    {"status": "SAVED", "current_version_id": vid, "current_version_number": number}, token)
    saved = saved.get("data", {})
    if (saved.get("id") != wid or saved.get("authoring_format") != NATIVE or saved.get("status") != "SAVED"
            or saved.get("current_version_id") != vid or saved.get("current_version_number") != number):
        raise TransferError("native workflow Save was not confirmed; inspect target before retrying")
    verify_version(request(opener, "GET", version_url, token=token), data["authoring"], wid, vid, number, saved=True)
    return {"workflow_id": wid, "version_id": vid, "status": "SAVED"}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--check", action="store_true", help="offline bundle validation (default)")
    modes.add_argument("--apply", action="store_true", help="interactive HPE login, create, and Save")
    parser.add_argument("--endpoint", default="http://127.0.0.1:18080")
    args = parser.parse_args(argv)
    try:
        root = Path(__file__).resolve().parent
        validate_bundle(root)
        endpoint = endpoint_url(args.endpoint)
        if not args.apply:
            print("Native transfer valid: one workflow, 10 tasks, scalar input example. No network requests made.")
            return 0
        if not sys.stdin.isatty():
            raise TransferError("--apply requires an interactive terminal")
        email = input("HPE admin email: ")
        password = getpass.getpass("HPE admin password: ")
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
        print(json.dumps(apply_bundle(root, endpoint, opener, email, password)))
        return 0
    except (TransferError, OSError) as error:
        print(f"Transfer stopped: {error}. No automatic retry or cleanup is performed.", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
